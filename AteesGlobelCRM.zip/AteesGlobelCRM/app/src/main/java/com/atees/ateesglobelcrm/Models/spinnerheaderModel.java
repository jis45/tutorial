package com.atees.ateesglobelcrm.Models;

import java.io.Serializable;

public class spinnerheaderModel implements Serializable {

    private  String headername;


    public spinnerheaderModel(){


    }

    public String getHeadername() {
        return headername;
    }

    public void setHeadername(String headername) {
        this.headername = headername;
    }
}
